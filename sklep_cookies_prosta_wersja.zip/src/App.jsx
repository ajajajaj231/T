import { useEffect, useState } from "react";
import Header from "./components/Header";
import Menu from "./components/Menu";
import Footer from "./components/Footer";
import ProductList from "./views/productList";
import "./App.css";
import {
    getProducts,
    getProductSortedByPrice,
    getProductSortedByPriceDesc,
    getProductsUnderPrice,
    getProductsOverPrice,
    getProductExactPrice,
} from "./controllers/productController";

const products = getProducts();

const FILTER_OPTIONS = [
    { value: "wszystkie", label: "Wszystkie" },
    { value: "sortAsc", label: "Cena: rosnąco" },
    { value: "sortDesc", label: "Cena: malejąco" },
    { value: "underPrice", label: "Cena poniżej..." },
    { value: "overPrice", label: "Cena powyżej..." },
    { value: "exactPrice", label: "Dokładna cena..." },
];
const COOKIE_TIME = 60 * 60 * 24 * 180;
function readCookie(name) {
    const cookies = document.cookie.split("; ");

    for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].split("=");

        if (cookie[0] === name) {
            return decodeURIComponent(cookie.slice(1).join("="));
        }
    }

    return null;
}
function writeCookie(name, value) {
    document.cookie = name + "=" + encodeURIComponent(value)
        + "; max-age=" + COOKIE_TIME + "; path=/; SameSite=Lax";
}
function deleteCookie(name) {
    document.cookie = name + "=; max-age=0; path=/";
}
function readJsonCookie(name, defaultValue) {
    const cookie = readCookie(name);

    if (cookie === null) {
        return defaultValue;
    }

    try {
        return JSON.parse(cookie);
    } catch {
        return defaultValue;
    }
}

function App() {
    const [query, setQuery] = useState("");
    const [category, setCategory] = useState("Wszystkie");
    const [filterType, setFilterType] = useState("wszystkie");
    const [priceInput, setPriceInput] = useState("");
    const [cartItems, setCartItems] = useState(() => {
        const saved = readJsonCookie("shop_cart", []);
        if (!Array.isArray(saved)) return [];
        return saved
            .filter(item => products.some(product => product.id === item.id))
            .map(item => {
                const product = products.find(entry => entry.id === item.id);
                return {
                    ...product,
                    qty: Number.isInteger(item.qty) && item.qty > 0
                        ? Math.min(item.qty, 99)
                        : 1
                };
            });
    });
    const [activePage, setActivePage] = useState("Lista");
    const [consent, setConsent] = useState(() => readJsonCookie("shop_cookie_consent", null));
    const [account, setAccount] = useState(() => {
        const saved = readJsonCookie("shop_demo_session", null);
        return saved && typeof saved.email === "string" ? saved : null;
    });
    const [accountEmail, setAccountEmail] = useState("");
    const [accountName, setAccountName] = useState("");
    const [accountMode, setAccountMode] = useState("login");
    const [accountMessage, setAccountMessage] = useState("");

    useEffect(() => {
        writeCookie("shop_cart", JSON.stringify(cartItems));
    }, [cartItems]);

    const categories = ["Wszystkie", ...new Set(products.map(product => product.category))];
    const needsPriceInput = ["underPrice", "overPrice", "exactPrice"].includes(filterType);
    const priceValue = parseFloat(priceInput);

    function getBaseProducts() {
        switch (filterType) {
            case "sortAsc": return getProductSortedByPrice();
            case "sortDesc": return getProductSortedByPriceDesc();
            case "underPrice": return !isNaN(priceValue) ? getProductsUnderPrice(priceValue) : products;
            case "overPrice": return !isNaN(priceValue) ? getProductsOverPrice(priceValue) : products;
            case "exactPrice": return !isNaN(priceValue) ? getProductExactPrice(priceValue) : products;
            default: return products;
        }
    }

    const filteredProducts = getBaseProducts()
        .filter(product => category === "Wszystkie" || product.category === category)
        .filter(product => product.name.toLowerCase().includes(query.toLowerCase()));

    function handleClear() {
        setQuery("");
        setCategory("Wszystkie");
        setFilterType("wszystkie");
        setPriceInput("");
    }

    function handleAddToCart(product) {
        setCartItems(previous => {
            const existing = previous.find(item => item.id === product.id);
            if (existing) {
                return previous.map(item => item.id === product.id
                    ? { ...item, qty: Math.min(item.qty + 1, 99) }
                    : item);
            }
            return [...previous, { ...product, qty: 1 }];
        });
    }

    function handleRemoveFromCart(id) {
        setCartItems(previous => previous.filter(item => item.id !== id));
    }

    function handleDecreaseQty(id) {
        setCartItems(previous => {
            const existing = previous.find(item => item.id === id);
            if (!existing || existing.qty <= 1) return previous.filter(item => item.id !== id);
            return previous.map(item => item.id === id ? { ...item, qty: item.qty - 1 } : item);
        });
    }

    function handleIncreaseQty(id) {
        setCartItems(previous => previous.map(item =>
            item.id === id ? { ...item, qty: Math.min(item.qty + 1, 99) } : item
        ));
    }

    function saveConsent() {
        writeCookie("shop_cookie_consent", "accepted");
        setConsent("accepted");
    }

    function handleAccountSubmit(event) {
        event.preventDefault();
        const email = accountEmail.trim().toLowerCase();
        if (!email || !email.includes("@")) {
            setAccountMessage("Wpisz poprawny adres e-mail.");
            return;
        }

        const name = accountMode === "register" ? accountName.trim() : "";
        if (accountMode === "register" && !name) {
            setAccountMessage("Wpisz nazwę użytkownika.");
            return;
        }

        const demoAccount = { email, name: name || email.split("@")[0] };
        writeCookie("shop_demo_session", JSON.stringify(demoAccount));
        setAccount(demoAccount);
        setAccountEmail("");
        setAccountName("");
        setAccountMessage("Zalogowano.");
    }

    function handleLogout() {
        deleteCookie("shop_demo_session");
        setAccount(null);
        setAccountMessage("Wylogowano.");
    }

    const totalItems = cartItems.reduce((sum, item) => sum + item.qty, 0);
    const totalPrice = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);

    return (
        <div className="app">
            <Header />

            <Menu activePage={activePage} onNavigate={setActivePage} cart={totalItems} />

            <main className="shop">
                {activePage === "Lista" && (
                    <>
                        <h1>Mój sklep</h1>
                        <p className="subtitle">najlepsze produkty</p>

                        <div className="filters">
                            <input
                                type="text"
                                placeholder="Szukaj produktu..."
                                value={query}
                                onChange={event => setQuery(event.target.value)}
                            />
                            <button onClick={handleClear}>Wyczyść</button>
                            <select value={category} onChange={event => setCategory(event.target.value)}>
                                {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                            </select>
                            <select value={filterType} onChange={event => { setFilterType(event.target.value); setPriceInput(""); }}>
                                {FILTER_OPTIONS.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
                            </select>
                            {needsPriceInput && (
                                <input
                                    type="number"
                                    placeholder="Podaj cenę..."
                                    value={priceInput}
                                    onChange={event => setPriceInput(event.target.value)}
                                />
                            )}
                        </div>

                        <ProductList products={filteredProducts} onAdd={handleAddToCart} />
                    </>
                )}

                {activePage === "Dodaj produkt" && (
                    <section>
                        <h1>Dodaj produkt</h1>
                        <p className="subtitle">formularz dodawania produktu</p>
                    </section>
                )}

                {activePage === "Koszyk" && (
                    <section>
                        <h1>Twój koszyk</h1>
                        {cartItems.length === 0 ? (
                            <p className="subtitle">Koszyk jest pusty.</p>
                        ) : (
                            <>
                                <table className="cart-table">
                                    <thead><tr><th>Produkt</th><th>Cena</th><th>Ilość</th><th>Suma</th><th></th></tr></thead>
                                    <tbody>
                                        {cartItems.map(item => (
                                            <tr key={item.id}>
                                                <td>{item.name}</td>
                                                <td>{item.price} zł</td>
                                                <td>
                                                    <div className="qty-controls">
                                                        <button onClick={() => handleDecreaseQty(item.id)} aria-label={"Zmniejsz ilość " + item.name}>−</button>
                                                        <span>{item.qty}</span>
                                                        <button onClick={() => handleIncreaseQty(item.id)} aria-label={"Zwiększ ilość " + item.name}>+</button>
                                                    </div>
                                                </td>
                                                <td>{item.price * item.qty} zł</td>
                                                <td><button onClick={() => handleRemoveFromCart(item.id)}>Usuń</button></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                                <p className="cart-total">Łącznie: <strong>{totalPrice} zł</strong></p>
                                <button onClick={() => setCartItems([])}>Wyczyść koszyk</button>
                            </>
                        )}
                    </section>
                )}

                {activePage === "Konto" && (
                    <section className="account-panel">
                        <h1>Konto</h1>
                        {account ? (
                            <>
                                <p>Witaj, <strong>{account.name}</strong>!</p>
                                <p className="subtitle">{account.email}</p>
                                <button className="primary-button" onClick={handleLogout}>Wyloguj</button>
                            </>
                        ) : (
                            <form className="account-form" onSubmit={handleAccountSubmit}>
                                <div className="account-tabs">
                                    <button type="button" className={accountMode === "login" ? "selected" : ""} onClick={() => { setAccountMode("login"); setAccountMessage(""); }}>Logowanie</button>
                                    <button type="button" className={accountMode === "register" ? "selected" : ""} onClick={() => { setAccountMode("register"); setAccountMessage(""); }}>Rejestracja</button>
                                </div>
                                {accountMode === "register" && (
                                    <label>
                                        Nazwa użytkownika
                                        <input value={accountName} onChange={event => setAccountName(event.target.value)} placeholder="Twoja nazwa" required />
                                    </label>
                                )}
                                <label>
                                    Adres e-mail
                                    <input type="email" value={accountEmail} onChange={event => setAccountEmail(event.target.value)} placeholder="adres@email.pl" required />
                                </label>
                                <button className="primary-button" type="submit">{accountMode === "register" ? "Utwórz konto" : "Zaloguj"}</button>
                                {accountMessage && <p className="account-message" role="status">{accountMessage}</p>}
                            </form>
                        )}
                    </section>
                )}
            </main>

            <Footer />

            {!consent && (
                <div className="cookie-banner">
                    <div>
                        <h2>Cookies</h2>
                        <p>Ta strona używa cookies, aby zapamiętać zawartość koszyka.</p>
                    </div>
                    <div className="cookie-actions">
                        <button className="primary-button" onClick={saveConsent}>Rozumiem</button>
                    </div>
                </div>
            )}

        </div>
    );
}

export default App;
